﻿namespace AplikasiPendaftaran
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            // Ukuran ClientSize disesuaikan agar pas dengan form Input Data Siswa
            this.ClientSize = new System.Drawing.Size(484, 511);
            this.Name = "Form1";
            this.Text = "Input Data Siswa v1.0";

            // Perhatian: Baris this.Load dihapus karena kita melakukan inisialisasi 
            // langsung di Constructor Form1.cs agar lebih simpel.

            this.ResumeLayout(false);
        }

        #endregion
    }
}